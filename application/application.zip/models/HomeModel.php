<?php
class HomeModel extends CI_Model{

    public function __construct() {
    }
}
?>
